<!-- jquery
============================================ -->
<script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
<!-- bootstrap JS
============================================ -->
<script src="assets/js/bootstrap.min.js"></script>
<!-- wow JS
============================================ -->
<script src="assets/js/wow.min.js"></script>
<!-- price-slider JS
============================================ -->
<script src="assets/js/jquery-price-slider.js"></script>
<!-- meanmenu JS
============================================ -->
<script src="assets/js/jquery.meanmenu.js"></script>
<!-- owl.carousel JS
============================================ -->
<script src="assets/js/owl.carousel.min.js"></script>
<!-- sticky JS
============================================ -->
<script src="assets/js/jquery.sticky.js"></script>
<!-- scrollUp JS
============================================ -->
<script src="assets/js/jquery.scrollUp.min.js"></script>
<!-- counterup JS
============================================ -->
<script src="assets/js/counterup/jquery.counterup.min.js"></script>
<script src="assets/js/counterup/waypoints.min.js"></script>
<script src="assets/js/counterup/counterup-active.js"></script>
<!-- mCustomScrollbar JS
============================================ -->
<script src="assets/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="assets/js/scrollbar/mCustomScrollbar-active.js"></script>
<!-- metisMenu JS
============================================ -->
<script src="assets/js/metisMenu/metisMenu.min.js"></script>
<script src="assets/js/metisMenu/metisMenu-active.js"></script>
<!-- morrisjs JS
============================================ -->
<script src="assets/js/morrisjs/raphael-min.js"></script>
<script src="assets/js/morrisjs/morris.js"></script>
<script src="assets/js/morrisjs/morris-active.js"></script>
<!-- morrisjs JS
============================================ -->
<script src="assets/js/sparkline/jquery.sparkline.min.js"></script>
<script src="assets/js/sparkline/jquery.charts-sparkline.js"></script>
<script src="assets/js/sparkline/sparkline-active.js"></script>
<!-- calendar JS
============================================ -->
<script src="assets/js/calendar/moment.min.js"></script>
<script src="assets/js/calendar/fullcalendar.min.js"></script>
<script src="assets/js/calendar/fullcalendar-active.js"></script>
<!-- data table JS
============================================ -->
<script src="assets/js/data-table/bootstrap-table.js"></script>
<script src="assets/js/data-table/tableExport.js"></script>
<script src="assets/js/data-table/data-table-active.js"></script>
<script src="assets/js/data-table/bootstrap-table-editable.js"></script>
<script src="assets/js/data-table/bootstrap-editable.js"></script>
<script src="assets/js/data-table/bootstrap-table-resizable.js"></script>
<script src="assets/js/data-table/colResizable-1.5.source.js"></script>
<script src="assets/js/data-table/bootstrap-table-export.js"></script>
<!--  editable JS
============================================ -->
<script src="assets/js/editable/jquery.mockjax.js"></script>
<script src="assets/js/editable/mock-active.js"></script>
<script src="assets/js/editable/select2.js"></script>
<script src="assets/js/editable/moment.min.js"></script>
<script src="assets/js/editable/bootstrap-datetimepicker.js"></script>
<script src="assets/js/editable/bootstrap-editable.js"></script>
<script src="assets/js/editable/xediable-active.js"></script>
<!-- Chart JS
============================================ -->
<script src="assets/js/chart/jquery.peity.min.js"></script>
<script src="assets/js/peity/peity-active.js"></script>
<!-- tab JS
============================================ -->
<script src="assets/js/tab.js"></script>
<!-- plugins JS
============================================ -->
<script src="assets/js/plugins.js"></script>
<!-- main JS
============================================ -->
<script src="assets/js/main.js"></script>
<script src="{{ asset('assets/pages/scripts/portlet-draggable.min.js') }}" type="text/javascript"></script>

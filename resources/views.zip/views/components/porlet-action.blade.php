<a class="btn btn-circle btn-icon-only btn-default" title="{{$title or ""}}" href="{{ $link }}" {!! $attributes or null !!}>
    <i class="{{ $icon }}"></i>
</a>

<div class="panel {{$class}}">
  <div class="panel-heading">{{$title}}</div>
  <div class="panel-body">
    {{$contenido}}
  </div>
</div>
<div class="panel-group accordion" id="{{ $id }}">
    {{ $slot }}
</div>